
function validateForm() {
  var z = document.forms["Formula"]["NatID"].value;
  var y = document.forms["Formula"]["LicNo"].value;
  var x = document.forms["Formula"]["fname"].value;
  var w = document.forms["Formula"]["lname"].value;
  var v = document.forms["Formula"]["Add1"].value;
  var u = document.forms["Formula"]["Add2"].value;
  var parish = document.forms["Formula"]["dropdown"];

  var error = true;

    /*Naterr = document.getElementById("Naterr")
    Licerr =  document.getElementById("Licerr")
    Ferr = document.getElementById("Ferr")
    Lerr = document.getElementById("Lerr")
    Aerr = document.getElementById("Aerr")
    Aderr = document.getElementById("Aderr")
    Perr = document.getElementById("Perr")*/

  if (z == "") {
      var a = document.getElementById("Naterr");
      a.innerHTML = "Error: invalid National ID format";
      error = false;
      //return false;
  }

  if (y == "") {
      var b = document.getElementById("Licerr");
      b.innerHTML = "Error: invalid License No. format";
      error = false;
      //return false;
  }

  if (x == "") {
    var c = document.getElementById("Ferr");
    c.innerHTML = "Error: invalid First Name format";
    error = false;
    //return false;
  }

  if (w == "") {
      var d = document.getElementById("Lerr");
      d.innerHTML = "Error: invalid Last Name format";
      error = false;
      //return false;
    }

    if(v == ""){
      var e = document.getElementById("Aerr");
      e.innerHTML = "Error: invalid Address 1 format";
      error = false;
      //return false;
    }

    if(u == ""){
      var f = document.getElementById("Aderr");
      f.innerHTML = "Error: invalid Address 2 format";
      error = false;
    //  return false;
  }
  t = getSelectedOption(parish);
  if (t.value == "") {
    Perr.innerHTML = "Error: invalid Parish format";
    error = false;
    //return false;
  }

  if (!isIdValid(z)) {
    Naterr.innerHTML = "Error: invalid National ID format";
    error = false;
  }

  if (!isNameValid(x)) {
    Ferr.innerHTML = "Error: invalid First Name format";
    error = false;
  }

  if (!isNameValid(w)) {
    Lerr.innerHTML = "Error: invalid Last Name format";
    error = false;
  }

  if (!isAddressValid(v)) {
    Aerr.innerHTML = "Error: invalid Address 1 format";
    error = false;
  }
    return error;
}

function getSelectedOption(sel) {
    for ( var i = 0, len = sel.options.length; i < len; i++ ) {
        var t = sel.options[i];
        if ( t.selected === true ) {
            break;
        }
    }
    return t;
}

function checkString(str, variabletype)
{
    for (var i = 0; i < str.length; i++) {
      if(variabletype == "number") {
        if (isNaN(str.charAt(i))) {
          return false;
        }
      }

      if(variabletype == "letter"){
        if(str.charAt(i)) {
            return false;
          }
        }

      if(variabletype == "alphanumeric"){
        if(str.charAt(i)) {
            return false;
        }
      }
    }
}

function isAlphaNumeric(password, strLength) {
  var char;

  for (i = 0; i < strLength; i++) {
    char = password.charAt(i);

    if (!(char > 47 && char < 58) && // numeric (0-9)
        !(char > 64 && char < 91) && // upper alpha (A-Z)
        !(char > 96 && char < 123)) { // lower alpha (a-z)
      return false;
    }
  }
  return true;
}

function isIdValid(id) {


  var NatIDLength = id.length;
  var split = id.split("-");

if (NatIDLength != ""){


  if (checkString(split[0], "number") ||
      checkString(split[1], "number")) {

        return true;
      }

  if(NatIDLength != 11){
    return false;
  }

  if ((split[0].length !=6) || (split[1].length !=4)) {
      return false;
  }

  return true;
}
}

function isNameValid(name){

  if (checkString(name, "letter")){
    var c = document.getElementById("Ferr");
    c.innerHTML = "Error: invalid First Name format";
    error = false;
    return error;
  }
}

function isAddressValid(addr){

  if(isAlphaNumeric(addr, strLength)){
    return true;
  }
}
 /*var inc = addr.includes(" ");

 if (!checkString(addr, "alphanumeric")){
   return false;
 }


  if(inc != "" ){
    return false;
  }
  return true;
}*/
function Validation()
{
  var publicUname = document.forms["Forming"]["uname"].value;
  var publicPasswd = document.forms["Forming"]["passwd"].value;
  var employUname = document.forms["login"]["EmployId"].value;
  var employPasswd = document.forms["login"]["Employpasswd"].value;

  var error = true;

    uerr = document.getElementById("Uerr")
    pserr = document.getElementById("Pserr")
    emplerr = document.getElementById("Emplerr")
    empswerr = document.getElementById("Empswerr")

    if (publicUname == "") {
        var a = document.getElementById("Uerr");
        a.innerHTML = "Error: Invalid Username";
        error = false;
}

  if (publicPasswd == ""){
    var b = document.getElementById("Pserr");
    b.innerHTML = "Error: Invalid Password";
    error = false;
  }

  if (employPasswd == ""){
    var b = document.getElementById("Pserr");
    b.innerHTML = "Error: Invalid Password";
    error = false;
  }

  isUsernameFormatValid(publicUname);

  if(!isPasswordFormatValid(publicPasswd)){
    pserr.innerHTML = "Error: invalid Password";
    error = false;
  }

  if(!isPasswordFormatValid(employPasswd)){
    empswerr.innerHTML = "Error: invalid Password";
    error = false;
  }

  if(!isEmployeeIdFormatValid(employUname)){
    emplerr.innerHTML = "Error: invalid Employee ID username";
    error = false;
  }
  return error;
}

isUsernameFormatValid(uname){

    var regexL = /^[a-zA-Z]+$/;

    var regexN = /^[0-9]+$/;

    var firstC = 0;

    var secondC = 4;

    if(uname.length == 8)
    {
    while(firstC < 4)
    {

      if (uname.charAt(firstC).match(regexL))
      {firstC++;}
      else
      {firstC = 5;}
    }

    while(secondC < 8)
    {
      if (uname.charAt(secondC).match(regexN))
      {secondC++;}
      else
      {secondC = 9;}
    }


      var value = firstC + secondC;

      if (value == 12)
      {
          return true;
      }
      else
      {
        Uerr.innerHTML = "Error: Invalid Username";
        return false;
      }
    }
    else
    {
      Uerr.innerHTML = "Error: Invalid Username";
    }
}


function isPasswordFormatValid(passwd)
{
  var regexL = /^[a-zA-Z]+$/;
  var regexN= /^[0-9]+$/;
  var count = 0;
  var numV = 0;
  var valC= 0;
  var firstC= 0;

if(passwd.length < 8 || passwd.length > 16)
{
  return false;
}
else
{
  while (count < passwd.length)
  {
      if (passwd.charAt(count).match(regexL))
      {valC = 1;}

      if(passwd.charAt(count).match(regexN))
      {numV = 1;}
      count++;
  }

  if (passwd.charAt(0).match(regexL))
  {firstC = 1;}

  if(valC == 1 && numV == 1 && firstC == 1)
  {
    return true;
  }
  else
  {
    return false;
  }
}
}

function isEmployeeIdFormatValid(empid)
{
  var regexN = /^[0-9]+$/;
  var num1 = 0;
  var num2= 4;
  var num3= 8;


  if(empid.length == 11)
  {



 if (empid.charAt(3).match("-") && empid.charAt(7).match("-"))
 {
 while(num1 < 3)
  {
    if (empid.charAt(num1).match(regexN))
    {num1++;}
    else
    {num1 = 4;}
  }

  while(num2 < 7)
  {
    if (empid.charAt(num2).match(regexN))
    {num2++;}
    else
    {num2 = 8;}
  }

  while(num3 < 11)
  {
    if (empid.charAt(num3).match(regexN))
    {num3++;}
    else
    {num3 = 12;}
  }
}
else
{
  var emplerr.innerHTML = "Error: Invalid Employee ID username";
}
}

    var num = num1 + num2 + num3;

    if (num == 21)
    {
        return true;
    }
    else
    {
      var emplerr.innerHTML = "Error: Invalid Employee ID username";
      return false;
    }
}

function validateUser(userdata, usertype)
{
  var public = localStorage.getItem(usertype);
  var publicO = JSON.parse(public);
  var num = 0;

  var login = JSON.parse(userdata);


  while(count < publicO.length)
  {

    if(login.password == publicO[num].password && login.username == publicO[num].username)
    {
      var object =
      {
        nationalId: publicO[num].nationalId,
        licenseNo: publicO[num].licenseNo,
        firstName: publicO[num].firstName,
        lastName: publicO[num].lastName,
        address1: publicO[num].address1,
        address2: publicO[num].address2,
        parish: publicO[num].parish,
        username: publicO[num].username,
        password: publicO[num].password
      };
      localStorage.setItem("driverSESSION", JSON.stringify(object));
      return true;
    }
    else
    {
      num++;
    }
  }

  Uerr.innerHTML = "Error: Invalid Username";
  return false;
}

function validateEmployee(userdata, usertype)
{
  var employee = localStorage.getItem(usertype);
  var employeeO = JSON.parse(employee);
  var num = 0;

  var login = JSON.parse(userdata);


  while(count < employeeO.length)
  {

    if(login.password == employeeO[num].password && login.employeeId == employeeO[num].employeeId)
    {
      var object =
      {
        employeeId: employeeO[num].employeeId,
        firstName: employeeO[num].firstName,
        lastName: employeeO[num].lastName,
        password: employeeO[num].password
      };

      localStorage.setItem("empSESSION", JSON.stringify(object));
      return true;
    }
    else
    {
      num++;
    }
  }

  var emplerr.innerHTML = "Error: invalid Login Info";
  return false;
}

function loadData()
{
  var driverArray = [
     {
        nationalId: "730209-3043",
        licenseNo: "135686819730209",
        firstName: "Andrew",
        lastName: "Pryor",
        address1: "31 ",
        address2: "Prior Park",
        parish: "St. James",
        username: "qwer1234",
        password:"andrewpryor123"
     },

     {
        nationalId: "671212-0404",
        licenseNo: "143647819671212",
        firstName: "Jennifer",
        lastName: "Davis",
        address1: "Wavell Ave",
        address2: "Black Rock",
        parish: "St. Michael",
        username: "geju7593",
        password:"anoth3rpass"
   },

   {
      nationalId: "790422-1209",
      licenseNo: "100893419790422",
      firstName: "Anderson",
      lastName: "Alleyne",
      address1: "Lascelles Terrace",
      address2: "The Pine",
      parish: "St. Michael",
      username: "oyqb4789",
      password:"thepassw0rd"
   }
  ]

  var employeeArray = [
   {
      employeeId: "545-700-593",
      firstName: "Merissa",
      lastName: "Halliwall",
      password:"f1rstpa55"
   },

   {
      employeeId: "090-728-221",
      firstName: "Terold",
      lastName: "Bostwick",
      password:"secur3acc3s5"
 },

 {
   employeeId: "147-830-662",
   firstName: "Vanda",
   lastName: "Marshall",
   password:"oll1p0ps"
 }
]

  //add to localStorage
  if(!localStorage.getItem("driverInfo"))
  {
     localStorage.setItem("driverInfo", JSON.stringify(driverArray));
  }
  if(!localStorage.getItem("employeeinfo"))
  {
     localStorage.setItem("employeeinfo", JSON.stringify(employeeArray));
  }

}
